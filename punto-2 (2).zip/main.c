/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>

#define PI 3.14159265

int main()
{
    float Real;
    float Imaginario;
    float Modulo;
    float Angulo;
    
    printf("Bienvenid@ al programa que lo ayudará a calcular la parte real e imaginaria de su número en formato polar\n");
    printf("A continuacion escriba el ángulo \n");
    scanf("%f",&Angulo);
    printf("A continuacion escriba el modulo \n");
    scanf("%f", &Modulo);
    
    Real=cos(Angulo*PI/180)*Modulo;
    Imaginario=sin(Angulo*PI/180)*Modulo;
    
    printf("La parte real es igual a  %f \n" , Real);
    printf("La parte imaginaria es igual a %f",Imaginario);

    return 0;
}
