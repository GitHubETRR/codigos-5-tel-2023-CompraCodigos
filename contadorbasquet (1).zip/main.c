/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int PE1 = 0;
int PE2 = 0;
int simples;
int dobles;
int triples;
int equipo;
int puntos;
int
main (void)
{

  do
    {

      printf("Bienvenid@ al programa sumador de puntos de la liga nacional de basquet Argentina\n");
      printf ("pulse 1 para sumarle puntos al local y 2 para el visitante");
      scanf ("%d", &equipo);
      if (equipo == 1)
	{
	  printf ("pulse 1 para simples, 2 para dobles y 3 para triples");
	  scanf ("%d", &puntos);
	}
      if (puntos == 1)
	{
	  PE1 = PE1 + 1;
	  printf ("puntos locales %d \n", PE1);
	  printf ("puntos visitantes %d", PE2);
	}
      if (puntos == 2)
	{
	  PE1 = PE1 + 2;
	  printf ("puntos locales %d \n", PE1);
	  printf ("puntos visitantes %d", PE2);
	}

      if (puntos == 3)
	{
	  PE1 = PE1 + 3;
	  printf ("puntos locales %d \n", PE1);
	  printf ("puntos visitantes %d", PE2);
	}
      if (equipo == 2)
	{
	  printf ("pulse 1 para simples, 2 para dobles y 3 para triples");
	  scanf ("%d", &puntos);
	}
      if (puntos == 1)
	{
	  PE2 = PE2 + 1;
	  printf ("puntos locales %d \n", PE1);
	  printf ("puntos visitantes %d", PE2);
	}
      if (puntos == 2)
	{
	  PE2 = PE2 + 2;
	  printf ("puntos locales %d \n", PE1);
	  printf ("puntos visitantes %d", PE2);
	}
      if (puntos == 3)
	{
	  PE2 = PE2 + 3;
	  printf ("puntos locales %d \n", PE1);
	  printf ("puntos visitantes %d", PE2);
	}
      return 0;
    }while (equipo!=0);
}
