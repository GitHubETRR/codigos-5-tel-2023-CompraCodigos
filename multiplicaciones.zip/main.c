#include <stdio.h>

int main()
{
    int numero=0;
    int resultado=0;
    int i=1;
            printf("Seleccione un numero para ver su tabla de multiplicacion basica \n");
      scanf("%d",&numero);
    for(i=1;i<11;i++){
        resultado=numero*i;
            printf("%d",resultado);
             printf("\n");
    }
    
    return (0);
}

